const { app, BrowserWindow, BrowserView, ipcMain } = require('electron/main')
const path = require('node:path')

function createWindow () {
    const mainWindow = new BrowserWindow({
      webPreferences: {
        preload: path.join(__dirname, 'preload.js')
      }
    })
  
    ipcMain.on('set-from-cef', (event, text) => {
        console.log("Received from CEF==> ", text)
    })

    createCefWindow(mainWindow)
  
    mainWindow.loadFile('index.html')
  }

function createCefWindow (win) {
    //new BrowserWindow({ width: 800, height: 600 })

    const view = new BrowserView({webPreferences: {
        preload: path.join(__dirname, 'preload.js')
      }});
    win.setBrowserView(view)
    view.setBounds({ x: 0, y: 0, width: 300, height: 300 })
    view.webContents.loadURL('https://devapp.magna.vip')
    view.webContents.on('did-finish-load', () => {
        // Example: Get the title of the page
        view.webContents.executeJavaScript(`
          document.addEventListener('click', function(event) {
            const text = document.getElementsByClassName('flipButton')[0].innerText;
              window.electronAPI.setFromCEF(text);
          });
        `);
      });
      view.webContents.on('console-message', (event, level, message, line, sourceId) => {
        console.log(`BrowserView Console (${line}): ${message}`);
      });

  ipcMain.on('set-from-main', (event, text) => {
   console.log("Received from MAIN==> ", text)
  })
}

app.whenReady().then(() => {
    createWindow()
    createCefWindow()

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow()
    }
  })
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})