const { contextBridge, ipcRenderer } = require('electron/renderer')

contextBridge.exposeInMainWorld('electronAPI', {
  setFromCEF: (title) => ipcRenderer.send('set-from-cef', title),
  setFromMain: (text) => ipcRenderer.send('set-from-main', text),
})