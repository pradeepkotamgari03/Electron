document.getElementById("main").addEventListener('click', function(event) {
    window.electronAPI.setFromMain('I am from MAIN==>');
});